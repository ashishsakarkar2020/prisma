<?php
/**
 * @author Olexandr Zanichkovsky <olexandr.zanichkovsky@zophiatech.com>
 * @package General
 */

/**
 * XmlImport library exception
 */
class XmlImportException extends Exception {}