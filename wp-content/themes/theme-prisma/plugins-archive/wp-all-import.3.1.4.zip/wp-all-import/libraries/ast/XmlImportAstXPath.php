<?php
/**
 * @author Olexandr Zanichkovsky <olexandr.zanichkovsky@zophiatech.com>
 * @package AST
 */

require_once dirname(__FILE__) . '/XmlImportAstLiteral.php';

/**
 * Represents XPath literal
 */
class XmlImportAstXPath extends XmlImportAstLiteral
{
  
}
