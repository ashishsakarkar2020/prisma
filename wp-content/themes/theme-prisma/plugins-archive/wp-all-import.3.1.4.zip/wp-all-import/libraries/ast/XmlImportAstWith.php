<?php
/**
 * @author Olexandr Zanichkovsky <olexandr.zanichkovsky@zophiatech.com>
 * @package AST
 */

require_once dirname(__FILE__) . '/XmlImportAstXpathClause.php';

/**
 * Represents a WITH clause
 */
class XmlImportAstWith extends XmlImportAstXPathClause
{
  
}
