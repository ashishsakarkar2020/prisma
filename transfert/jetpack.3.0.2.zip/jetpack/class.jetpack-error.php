<?php

class Jetpack_Error extends WP_Error {}
